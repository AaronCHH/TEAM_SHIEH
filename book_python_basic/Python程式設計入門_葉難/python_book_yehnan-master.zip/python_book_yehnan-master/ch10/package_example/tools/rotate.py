
def rotate():
    return 'rotate'

