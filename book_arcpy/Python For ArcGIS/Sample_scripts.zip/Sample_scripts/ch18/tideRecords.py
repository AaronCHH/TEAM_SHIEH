# tideRecords.py
# Purpose: Practice performing dictionary operations.
# Usage: No arguments needed.

tides = {'G1': [1, 6], 'G2': [2], 'G3': [3, 8, 9]}
