# punctuationArt.py
def printBird():
    '''Print a punctiation art bird.'''
    print """
      ,,,     ::.
    <*~)    ;;
    (   @}//
     ''
    """
# Run the script once without calling the function to confirm
#    that it doesn't print anything.
# Then uncomment the following line of code and run again:
##printBird()