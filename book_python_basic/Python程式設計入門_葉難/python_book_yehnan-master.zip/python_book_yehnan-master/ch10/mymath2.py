


_x = 'xxx'
_y = 3
pi = 3.14
def gcd(a, b): pass
def factorial(n): pass
def _z(): pass
