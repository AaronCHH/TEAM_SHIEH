# trapezoid.py

# Quad1: b1 = 4, b2 = 4, alt = 6, angle = 90
b1 = 4
b2 = 4
alt = 6
angle = 90
print 'Quad1: b1 = 4, b2 = 4, alt = 6, angle = 90'

# Quad2: b1 = 5, b2 = 5, alt = 5, angle = 30
b1 = 5
b2 = 5
alt = 5
angle = 30

print 'Quad2: b1 = 5, b2 = 5, alt = 5, angle = 30'

# Quad3: b1 = 8, b2 = 8, alt = 6, angle = 60
b1 = 8
b2 = 8
alt = 6
angle = 60

print 'Quad3: b1 = 8, b2 = 8, alt = 6, angle = 60'
