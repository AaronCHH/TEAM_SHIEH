# owl.py


def printOwl():
    '''Print punctuation art owl.'''
    print """
  ^----^
  (O,O)
 / ) ) \\
---J-J---
    """

print 'Whoooo, whooo.'
