"""scopetest: our scope test module"""
v = 6
def f(x):
    """f: scope test function"""
    print ("global: ", list(globals().keys()))
    print ("entry local:", locals())
    y = x
    w = v
    print ("exit local:", locals())
