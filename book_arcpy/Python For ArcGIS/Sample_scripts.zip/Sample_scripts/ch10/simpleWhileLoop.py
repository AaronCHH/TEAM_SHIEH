# simpleWhileLoop.py
x = 1
while x <= 5:
    print x
    x = x + 1
print "I'm done!"
