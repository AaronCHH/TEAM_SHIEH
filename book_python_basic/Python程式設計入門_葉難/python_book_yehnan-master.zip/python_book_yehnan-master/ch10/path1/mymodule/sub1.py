

def foo():
    return 'foo'
    