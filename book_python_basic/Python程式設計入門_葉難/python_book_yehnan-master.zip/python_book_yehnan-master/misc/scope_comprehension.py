
# i = 'abc'
# print(i)
# x = [i**2 for i in range(10)]
# print(i)        # 2.x 3.x different

# i = 'abc'
# print(i)
# x = {i**2 for i in range(10)}
# print(i)

# i = 'abc'
# print(i)
# x = {i:i**2 for i in range(10)}
# print(i)

# i = 'abc'
# print(i)
# x = (i**2 for i in range(10))
# print(i)

# i = 'abc'
# print(i)
# for i in range(10):
    # pass
# print(i)

# print(globals())
