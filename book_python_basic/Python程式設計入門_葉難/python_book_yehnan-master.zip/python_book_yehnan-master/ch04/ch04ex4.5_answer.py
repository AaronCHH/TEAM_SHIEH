

data = [('John', 40, 174, 65), ('Amy', 28, 165, 44), ('Jessie', 32, 158, 45)]

data_sorted = sorted(data, key=lambda x: x[1])

print(data_sorted)

