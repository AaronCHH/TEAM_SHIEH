# simpleForLoop.py
myFiles = ['data1.shp', 'data2.shp',  'data3.shp', 'data4.shp']
for currentFile in myFiles:
    print currentFile
print "I'm done!"
