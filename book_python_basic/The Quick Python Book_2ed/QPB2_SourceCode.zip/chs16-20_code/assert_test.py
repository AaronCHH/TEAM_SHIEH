def example(param):
    assert param > 0
    # do stuff here
