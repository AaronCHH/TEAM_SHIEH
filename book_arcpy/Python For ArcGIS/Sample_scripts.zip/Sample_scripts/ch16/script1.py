import script2

print 'I am in script 1, which just imported script 2.'

####import sys, os
####scriptPath = os.path.abspath(__file__)

####scriptDir = os.path.dirname(scriptPath) 
####relativePath = 'otherCode' 
####modulePath = os.path.join(scriptDir, relativePath)
####
####sys.path.append(modulePath)
####
####import script4