《Python程式設計入門》書中的範例程式原始碼，以及練習題所需檔案。<br/>
出版社：博碩<br/>
書號：PG21421<br/>

![書籍封面](cover.jpg)

勘誤表請見
http://yehnan.blogspot.tw/2015/03/python_30.html
