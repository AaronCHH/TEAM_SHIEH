r"""

>>> import mathproj
Hello from mathproj init


"""

import doctest

doctest.testmod(optionflags=doctest.NORMALIZE_WHITESPACE)
