
scores = (98, 78, 64, 55, 61, 82)
lowerThan60 = False
for x in scores:
    if x < 60:
        lowerThan60 = True
        break

print(lowerThan60)
