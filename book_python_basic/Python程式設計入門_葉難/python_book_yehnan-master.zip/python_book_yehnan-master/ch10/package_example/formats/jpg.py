

from . import bar
from .. import info
from ..gui import display
from ..gui import menu
from ..gui.canvas import *

print(bar.__name__)
print(info.__name__)
print(display())
print(menu.__name__)
print(clear())

