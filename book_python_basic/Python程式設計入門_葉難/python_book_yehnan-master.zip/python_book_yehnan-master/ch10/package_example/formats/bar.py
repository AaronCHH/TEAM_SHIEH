

def square(x):
    return x * x
