
# -*- coding: utf-8 -*-

pi = 3.14
data = [30, 41, 52, 63, 74]
z = 100

def foo(x, y):
    return x + y + z

