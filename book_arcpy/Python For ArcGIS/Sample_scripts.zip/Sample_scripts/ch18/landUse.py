# landUse.py
# Purpose: Practice performing dictionary operations.
# Usage: No arguments needed.

landUse = {'res': 1, 'com': 2, 'ind': 3, 'other': [4, 5, 6, 7]}
