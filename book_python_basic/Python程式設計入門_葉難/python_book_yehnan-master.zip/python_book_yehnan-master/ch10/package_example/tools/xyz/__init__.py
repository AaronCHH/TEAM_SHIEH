


from ... import info

print(info.__name__)
