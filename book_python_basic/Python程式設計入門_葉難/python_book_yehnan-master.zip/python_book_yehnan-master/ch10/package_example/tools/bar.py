

def bar():
    return 'bar'



