

# date, name, fruit, number
data = ("""
2014/05/06, Amy, apple, 50,
2014/05/06, Bob, banana, 35,
2014/05/06, Cathy, grape, 40,
2014/05/07, Amy, apple, 42,
2014/05/07, Cathy, banana, 30,
2014/05/07, David, banana, 33,
2014/05/07, Bob, grape, 44,
2014/05/08, Amy, apple, 55,
2014/05/08, Bob, grape, 56,
2014/05/08, David, banana, 51,
2014/05/10, David, grape, 25,
2014/05/10, Cathy, grape, 26,
2014/05/10, David, banana, 51,
2014/05/10, Amy, grape, 23,
2014/05/10, David, apple, 11,
""")

# fruit : price
prices = {'apple': 30, 'banana': 22, 'grape': 25}

