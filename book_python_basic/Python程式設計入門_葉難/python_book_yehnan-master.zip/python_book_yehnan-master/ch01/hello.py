print('Hello Python')
