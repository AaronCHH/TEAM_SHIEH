
colors = ['red', 'green', 'blue']
animals = ['cat', 'dog', 'horse', 'sheep']
results = []
for x in colors:
    for y in animals:
        results += [x + ' ' + y]

print(results)

