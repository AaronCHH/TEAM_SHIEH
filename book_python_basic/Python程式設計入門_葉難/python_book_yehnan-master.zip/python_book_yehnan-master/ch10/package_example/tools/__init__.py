

# from foo import *      # 2.x
# from bar import *      # 2.x

# from package_example.tools.foo import *
# from package_example.tools.bar import *

from .foo import *
from .bar import *

