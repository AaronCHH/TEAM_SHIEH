import os
print 'Inside script4'
print os.path.abspath(__file__)