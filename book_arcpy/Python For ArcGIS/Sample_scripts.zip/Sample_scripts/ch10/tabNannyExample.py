# tabNannyExample.py
decList = []
for num in range(5):
    decNum = num + 0.5
 	decList.append(decNum)
print decList
