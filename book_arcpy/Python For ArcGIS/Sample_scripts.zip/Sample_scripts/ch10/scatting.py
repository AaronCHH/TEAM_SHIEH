# scatting.py
# Purpose: Use nested loops to scat.
print '\nskeep-de'
for i in range(2):
    print '    beep'
    for j in range(3):
        print '        bop'
print 'ba-doop!'
