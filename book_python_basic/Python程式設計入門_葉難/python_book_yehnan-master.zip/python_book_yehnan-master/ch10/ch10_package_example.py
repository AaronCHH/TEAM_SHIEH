


# import package_example.gui.menu
# import package_example.gui.canvas
# from package_example.gui import *

# print(display())
# print(draw())
# print(menu.__name__)
# print(canvas.__name__)


# print(canvas.__name__)
# print(menu.__name__)

# import package_example.formats.foo
# print(type(package_example.formats.foo))

# from package_example.formats import foo
# print(type(foo))

# import package_example.tools
# print(package_example.tools.foo())
# print(package_example.tools.bar())

# from package_example.tools import rotate
# print(rotate.rotate())

# import package_example.formats.jpg
# import package_example.formats.bar
# print(package_example.formats.bar.__name__)

# import package_example

# import package_example.tools.xyz

# from . import info
# print(info.__name__)

import package_example.formats.foo
print(package_example.formats.foo.sos(3, 4))
print(package_example.__path__)
