# add_version1.py adds two numbers.
a = 2
b = 3
c = a + b
# format(c) substitutes the value of c for {0} in the print statement.
print 'The sum is {0}.'.format(c)
