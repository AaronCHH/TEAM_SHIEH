import sys
def main():
    print("this is our second test script file")
    print(sys.argv)
main()
