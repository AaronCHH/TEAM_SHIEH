def main():                 
    print("this is our first test script file")
main()
